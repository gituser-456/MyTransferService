package com.dws.challenge.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.dws.challenge.domain.Account;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TransferService {

	private final NotificationService notificationService;
	private final AccountsService accountsService;

	private static Logger log = LoggerFactory.getLogger(TransferService.class);

	public TransferService(NotificationService notificationService, AccountsService accountsService) {
		this.notificationService = notificationService;
		this.accountsService = accountsService;

	}

	public void transfer(String accountFromId, String accountToId, BigDecimal amount) {
		log.info("start Tranfer amount {}");
		if (amount.compareTo(BigDecimal.ZERO) <= 0) {
			throw new IllegalArgumentException("Transfer amount must be positive");
		}

		Account accountFrom = accountsService.getAccount(accountFromId);
		Account accountTo = accountsService.getAccount(accountToId);

		Account firstLock = accountFrom.getAccountId().compareTo(accountTo.getAccountId()) < 0 ? accountFrom
				: accountTo;
		Account secondLock = accountFrom.getAccountId().compareTo(accountTo.getAccountId()) < 0 ? accountTo
				: accountFrom;

		// Acquire locks in the same order of accountId's to avoid deadLocks
		firstLock.getLock().lock();
		secondLock.getLock().lock();

		try {
			if (accountFrom.withdraw(amount)) {
				accountTo.deposit(amount);
				notificationService.notifyAboutTransfer(accountFrom, amount + " transfered to " + accountToId);
				notificationService.notifyAboutTransfer(accountTo, amount + " received from" + accountFromId);
				
			} else {
				throw new IllegalStateException("Insufficient funds in account " + accountFromId);
			}
		} finally {
			firstLock.getLock().unlock();
			secondLock.getLock().unlock();
		}
		log.info("End method transfer ");
	}
}