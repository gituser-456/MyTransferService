package com.dws.challenge.domain;

import java.math.BigDecimal;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class Account {

	@NotNull
	@NotEmpty
	private final String accountId;

	@NotNull
	@Min(value = 0, message = "Initial balance must be positive.")
	private BigDecimal balance;
	
	private final Lock lock;

	public Account(String accountId) {
		this.accountId = accountId;
		this.balance = BigDecimal.ZERO;
		this.lock = new ReentrantLock();
	}

	@JsonCreator
	public Account(@JsonProperty("accountId") String accountId, @JsonProperty("balance") BigDecimal balance) {
		this.accountId = accountId;
		this.balance = balance;
	}

	public synchronized BigDecimal getBalance() {
		return this.balance;
	}

	public synchronized void deposit(BigDecimal amount) {
		balance = balance.add(amount);
	}

	public synchronized boolean withdraw(BigDecimal amount) {
		if (balance.compareTo(amount) >= 0) {
			balance = balance.subtract(amount);
			return true;
		}
		return false;
	}

	public String getAccountId() {
		return accountId;
	}

	public Lock getLock() {
		return lock;
	}
	
	
}
