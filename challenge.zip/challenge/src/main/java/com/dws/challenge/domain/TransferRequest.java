package com.dws.challenge.domain;

import java.math.BigDecimal;
import java.util.concurrent.locks.ReentrantLock;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TransferRequest {

	@NotNull
	@NotEmpty
	@JsonProperty("accountFromId")
	private final String accountFromId;
	
	@NotNull
	@NotEmpty
	@JsonProperty("accountToId")
	private final String accountToId;

	@NotNull
	@Min(value = 1, message = "Amount to transfer should be positive")
	@JsonProperty("amount")
	private BigDecimal amount;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getAccountFromId() {
		return accountFromId;
	}

	public String getAccountToId() {
		return accountToId;
	}
	
	
}
