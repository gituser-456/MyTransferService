package com.dws.challenge;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.concurrent.locks.ReentrantLock;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.dws.challenge.domain.Account;
import com.dws.challenge.service.NotificationService;
import com.dws.challenge.service.TransferService;
import com.example.demo.Service.AccountService;

@ExtendWith(SpringExtension.class)

@SpringBootTest

public class TransferServiceTest {

	@Autowired
	NotificationService notificationService;

	@MockBean
	AccountService accountsService;

	@Autowired
	TransferService transferService;

	@Test
	public void testValidTransfer() {

		String accountFromId = "ABC123";

		String accountToId = "ACB345";

		BigDecimal amount = new BigDecimal(1234);

		OngoingStubbing<Account> accountFrom = when(this.accountsService.getAccount(accountFromId))

				.thenReturn(new Account("ABC123", new BigDecimal(5000), new ReentrantLock()));

		when(this.accountsService.getAccount(accountToId))

				.thenReturn(new Account("ABC345", new BigDecimal(100), new ReentrantLock()));

		transferService.transfer(accountFromId, accountToId, amount);

	}

	@Test
	public void testInValidTransfer() {

		String accountFromId = "ABC123";

		String accountToId = "ACB345";

		BigDecimal amount = new BigDecimal(0);

		when(this.accountsService.getAccount(accountFromId))

				.thenReturn(new Account("ABC123", new BigDecimal(5000), new ReentrantLock()));

		when(this.accountsService.getAccount(accountToId))

				.thenReturn(new Account("ABC345", new BigDecimal(100), new ReentrantLock()));

		assertThrows(IllegalArgumentException.class, () -> transferService.transfer(accountFromId, accountToId, amount),

				"Transfer amount must be positive");

	}

	@Test

	public void testInSufficientFund() {

		String accountFromId = "ABC123";

		String accountToId = "ACB345";

		BigDecimal amount = new BigDecimal(10);

		when(this.accountsService.getAccount(accountFromId))

				.thenReturn(new Account("ABC123", new BigDecimal(0), new ReentrantLock()));

		when(this.accountsService.getAccount(accountToId))

				.thenReturn(new Account("ABC345", new BigDecimal(100), new ReentrantLock()));

		assertThrows(IllegalStateException.class, () -> transferService.transfer(accountFromId, accountToId, amount),

				"Insufficient funds in account");

	}

}